from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    PerspectiveViewSet, 
    PerspectiveFieldViewSet,
    ProjectPerspectiveViewSet,
    UserPerspectiveAnswerViewSet
)

router = DefaultRouter()
router.register(r'fields', PerspectiveFieldViewSet)
router.register(r'perspectives', PerspectiveViewSet)
router.register(r'project-perspectives', ProjectPerspectiveViewSet, basename='project-perspective')
router.register(r'user-answers', UserPerspectiveAnswerViewSet, basename='user-perspective-answer')

urlpatterns = [
    path('', include(router.urls)),
] 